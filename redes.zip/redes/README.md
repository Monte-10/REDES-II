# Arrancar el servidor
make all
./server

# Mandar peticiones del cliente
Desde otra terminal diferente al servidor ejecutar el comando que corresponda
## Verbo OPTIONS
curl -i -X OPTIONS http://localhost:8080

# Troubleshooting
## lib_bind(): Address already in use
Este error aparece si se ejecuta el servidor de manera muy seguida; aun no se ha cerrado
el puerto 8080 para poder usarlo de nuevo. Unicamente hay que esperar un rato para volver
a ejecutarlo.
## curl: (35) Recv failure: Connection reset by peer
Este error puede darse si se escribe *https* en vez de *http* en la url *http://localhost:8080*.